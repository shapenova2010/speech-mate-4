SpeechMate KZ — updated prototype

FILES
- SpeechMate_KZ_working_prototype.html — website prototype
- speechmate-ai-worker.js — server-side AI proxy for Cloudflare Workers

IMPORTANT
The website is a static HTML prototype. A real AI model cannot be safely called directly from browser code because that would expose the API key. The Worker keeps OPENAI_API_KEY on the server.

CONNECT THE AI (an adult project owner should manage the API account and billing)
1. Open Cloudflare Dashboard → Workers & Pages → Create Worker.
2. Paste speechmate-ai-worker.js into the Worker editor and deploy.
3. In Worker Settings → Variables and Secrets, add secret OPENAI_API_KEY with the provider key. Do NOT paste it into the HTML file or the website profile.
4. Optionally add variable OPENAI_MODEL (default: gpt-4o-mini).
5. Add APP_ORIGIN with the exact published website origin, e.g. https://YOUR-USERNAME.github.io (use the actual origin of the deployed site).
6. Copy the Worker URL. Open the website → Profile → AI server address and paste the Worker URL ending in /api/chat.

NOTE: The Worker code above expects the route /api/chat. If the deployed Worker URL is https://name.workers.dev, enter https://name.workers.dev/api/chat. If your Worker is deployed at root only, add a route or adjust the URL handling in the Worker.

CURRENT LIMITATIONS
- Kazakh interface translations are a starter dictionary, not yet a complete professional localization of every screen and every dynamic message.
- QR image and URL settings currently save locally in the current browser only. They are not shared across visitors and are not protected by owner authentication. Do not treat this as secure admin functionality.
- Speech recognition depends on browser support and permission. The text analyzer cannot measure pronunciation, intonation, voice quality, or acoustic pauses.
- AI functions work only after the Worker is deployed and configured with a valid provider key.

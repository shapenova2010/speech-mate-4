// SpeechMate KZ — Cloudflare Worker (server-side AI proxy)
// Deploy this Worker and add OPENAI_API_KEY as a secret in Cloudflare.
// Optional vars: OPENAI_MODEL (default gpt-4o-mini), APP_ORIGIN (your GitHub Pages origin).
// Never put OPENAI_API_KEY in the HTML or browser localStorage.

const SYSTEM = `Ты — доброжелательный тренер речи для подростков 12–17 лет.
Отвечай на языке, указанном в language: ru = русский, kk = қазақша, bi = естественный русский/казахский билингвальный режим.
Не оценивай личность пользователя. Давай конкретную, уважительную обратную связь на уровне школьника.
Не выдумывай акустические показатели: тебе доступен только распознанный текст, а не аудио.
Не называй число-балл, если его нельзя обосновать. Не считай естественные паузы или переключение RU/KZ ошибкой.
Будь конкретным: цитируй короткие фрагменты ответа пользователя, объясняй сильные стороны, указывай 2–3 приоритетных улучшения и давай пример улучшенной формулировки.
Не проси личные данные.`;

const cors = (origin, allowed) => ({
  "Access-Control-Allow-Origin": allowed && allowed !== "*" ? allowed : "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Vary": "Origin"
});

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const allowed = env.APP_ORIGIN || "*";
    if (request.method === "OPTIONS") return new Response(null, { headers: cors(origin, allowed) });
    if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
    if (allowed !== "*" && origin !== allowed) return new Response("Origin not allowed", { status: 403 });
    if (!env.OPENAI_API_KEY) return Response.json({ error: "OPENAI_API_KEY is not configured" }, { status: 503, headers: cors(origin, allowed) });

    try {
      const body = await request.json();
      const task = String(body.task || "");
      const language = ["ru", "kk", "bi"].includes(body.language) ? body.language : "ru";
      const safe = (v, max = 12000) => String(v || "").slice(0, max);
      let instruction = "";
      if (task === "conversation") {
        const history = Array.isArray(body.history) ? body.history.slice(-8).map(m => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: safe(m.content, 2500)
        })) : [];
        instruction = "Продолжи естественный диалог. Сначала отреагируй именно на мысль собеседника, затем задай один содержательный открытый вопрос. Не используй шаблонные фразы.";
        body.messages = history.length ? history : [{ role: "user", content: safe(body.message) }];
      } else if (task === "debate") {
        instruction = `Ты оппонент в школьных дебатах. Тема: ${safe(body.topic, 500)}. Позиция ученика: ${safe(body.position, 500)}. Аргумент ученика: ${safe(body.argument, 4000)}. Ответь конкретным контраргументом, укажи, что в его доводе убедительно или недостаточно доказано, и задай один точный вопрос. Не приписывай ученику того, чего он не говорил.`;
      } else if (task === "speech_analysis") {
        instruction = `Проанализируй ВЕСЬ текст ответа, не только начало. Текст: ${safe(body.transcript)}. Длительность записи (если известна): ${Number(body.duration_seconds) || 0} секунд. Разделы: 1) главная мысль и раскрытие темы; 2) структура (тезис, причины, примеры, вывод); 3) связность и переходы; 4) аргументация и конкретика; 5) повторы и возможные слова-паразиты (не объявляй обычные слова ошибками); 6) 2 сильные стороны; 7) до 3 конкретных улучшений; 8) пример более ясной формулировки одного фрагмента. Не оценивай дикцию, произношение, тембр, интонацию или реальный темп по тексту.`;
      } else if (task === "explain") {
        instruction = `Понятие: ${safe(body.concept, 500)}. Объяснение ученика: ${safe(body.answer)}. Проверь точность смысла, простоту объяснения, наличие примера и понятность. Дай доброжелательную конкретную обратную связь и один следующий шаг.`;
      } else {
        return Response.json({ error: "Unknown task" }, { status: 400, headers: cors(origin, allowed) });
      }

      const messages = [
        { role: "system", content: SYSTEM + "\n\n" + instruction },
        ...(task === "conversation" ? body.messages : [{ role: "user", content: instruction }])
      ];
      const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: env.OPENAI_MODEL || "gpt-4o-mini",
          messages,
          temperature: 0.6,
          max_tokens: 1100
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) return Response.json({ error: data.error?.message || "AI provider error" }, { status: 502, headers: cors(origin, allowed) });
      const reply = data.choices?.[0]?.message?.content?.trim();
      return Response.json({ reply: reply || "Не удалось сформировать ответ." }, { headers: cors(origin, allowed) });
    } catch (error) {
      return Response.json({ error: "Invalid request or server error" }, { status: 400, headers: cors(origin, allowed) });
    }
  }
};
